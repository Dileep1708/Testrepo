﻿using Microsoft.AspNetCore.Mvc;
using SampleMVC.Models;
using SampleMVC.Repositories;
using System.Threading.Tasks;

namespace SampleMVC.Controllers
{
    public class PrizeController : Controller
    {
        private readonly IDataRepository _dataRepository;

        public PrizeController(IDataRepository dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(PrizeModel model)
        {
            if (ModelState.IsValid)
            {
                _dataRepository.CreatePrize(model);
                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }
    }
}
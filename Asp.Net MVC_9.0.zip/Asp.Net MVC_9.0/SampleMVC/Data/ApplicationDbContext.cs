﻿using Microsoft.EntityFrameworkCore;
using SampleMVC.Models;

namespace SampleMVC.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<PersonModel> Persons { get; set; }
        public DbSet<TeamModel> Teams { get; set; }
        public DbSet<PrizeModel> Prizes { get; set; }
        public DbSet<TournamentModel> Tournaments { get; set; }
        public DbSet<MatchupModel> Matchups { get; set; }
        public DbSet<MatchupEntryModel> MatchupEntries { get; set; }
    }
}
﻿using SampleMVC.Models;

namespace SampleMVC.Models
{
    public class MatchupEntryModel
    {
        public int Id { get; set; }
        public TeamModel TeamCompeting { get; set; }
        public double Score { get; set; }
        public MatchupModel ParentMatchup { get; set; }
    }
}
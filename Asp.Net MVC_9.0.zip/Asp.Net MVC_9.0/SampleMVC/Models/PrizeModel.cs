﻿using System.ComponentModel.DataAnnotations;

namespace SampleMVC.Models
{
    public class PrizeModel
    {
        public int Id { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Place Number must be greater than 0.")]
        public int PlaceNumber { get; set; }

        [Required]
        public string PlaceName { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Prize Amount must be a positive number.")]
        public decimal PrizeAmount { get; set; }

        [Range(0, 100, ErrorMessage = "Prize Percentage must be between 0 and 100.")]
        public double PrizePercentage { get; set; }
    }
}
﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using SampleMVC.Models;
using SampleMVC.Repositories;
using SampleMVC.Data;

namespace SampleMVC.Repositories
{
    public class DataRepository : IDataRepository
    {
        private readonly ApplicationDbContext _context;

        public DataRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void CreatePerson(PersonModel model)
        {
            _context.Persons.Add(model);
            _context.SaveChanges();
        }

        public void CreatePrize(PrizeModel model)
        {
            _context.Prizes.Add(model);
            _context.SaveChanges();
        }

        public void CreateTeam(TeamModel model)
        {
            _context.Teams.Add(model);
            _context.SaveChanges();
        }

        public void CreateTournament(TournamentModel model)
        {
            _context.Tournaments.Add(model);
            _context.SaveChanges();
        }

        public List<PersonModel> GetPerson_All()
        {
            return _context.Persons.ToList();
        }

        public List<TeamModel> GetTeams_All()
        {
            return _context.Teams.Include(t => t.TeamMembers).ToList();
        }

        public List<TournamentModel> GetTournament_All()
        {
            return _context.Tournaments
                .Include(t => t.EnteredTeams)
                .ThenInclude(tm => tm.TeamMembers)
                .Include(t => t.Prizes)
                .Include(t => t.Rounds)
                .ThenInclude(r => r)
                .ThenInclude(e => e)
                .ThenInclude(e => e)
                .Include(t => t.Rounds)
                .ThenInclude(r => r)
                .ThenInclude(e => e)
                .ToList();
        }

        public void UpdateMatchup(MatchupModel model)
        {
            _context.Matchups.Update(model);
            _context.SaveChanges();
        }

        public void CompleteTournament(TournamentModel model)
        {
            _context.Tournaments.Remove(model);
            _context.SaveChanges();
        }
    }
}
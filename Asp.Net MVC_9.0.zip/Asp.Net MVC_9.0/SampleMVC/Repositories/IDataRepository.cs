﻿using System.Collections.Generic;
using SampleMVC.Models;

namespace SampleMVC.Repositories
{
    public interface IDataRepository
    {
        void CreatePerson(PersonModel model);
        void CreatePrize(PrizeModel model);
        void CreateTeam(TeamModel model);
        void CreateTournament(TournamentModel model);
        List<PersonModel> GetPerson_All();
        List<TeamModel> GetTeams_All();
        List<TournamentModel> GetTournament_All();
        void UpdateMatchup(MatchupModel model);
        void CompleteTournament(TournamentModel model);
    }
}